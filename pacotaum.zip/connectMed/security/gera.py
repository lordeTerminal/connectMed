import time
import pyotp
import qrcode
inicial=int(input("""
      Bem vindo ao autenticador:
      digite 1 para novo usuario.
      digite 2 para recuperar acesso"""))
if inicial == 1:
    key = pyotp.random_base32()
elif inicial == 2:
    key = str(input("entre com chave de segurança: >"))
else:
    print("comando não reconhecido, incidente de segurança será reportado.")
#implementar registro na paradinha do banco de dados do user
print(key)
#puxar name do banco de dados...
uri = pyotp.totp.TOTP(key).provisioning_uri(name="Raphael" ,issuer_name="SaudeOsasco")
print(uri)
qrcode.make(uri).save("ValidarEDestruirDepois.png")
