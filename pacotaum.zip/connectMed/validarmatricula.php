<?php
$loginvalidar = $_POST['loginvalidar'];

echo $loginvalidar;

?>
